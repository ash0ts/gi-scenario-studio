module EcoCorridorEngine

using Circuitscape
using JSON3
using LinearAlgebra

const PROTOCOL_VERSION = "1.0"
const ENGINE_VERSION = "5.17.1"

function contained_path(root::String, relative::String)::String
    isabspath(relative) && error("absolute protocol path is forbidden")
    target = realpath(joinpath(root, relative))
    relative_target = relpath(target, realpath(root))
    (isabspath(relative_target) || ".." in splitpath(relative_target)) &&
        error("protocol path escapes the run directory")
    return target
end

function checked_input_path(root::String, relative::String)::String
    path = contained_path(root, relative)
    isfile(path) || error("required engine input is absent: $relative")
    islink(path) && error("symlinked engine inputs are forbidden")
    return path
end

function contained_output_path(root::String, relative::String)::String
    isabspath(relative) && error("absolute protocol output path is forbidden")
    target = abspath(normpath(joinpath(root, relative)))
    relative_target = relpath(target, abspath(root))
    (isabspath(relative_target) || ".." in splitpath(relative_target)) &&
        error("protocol output path escapes the run directory")
    return target
end

function parse_args(arguments)::Tuple{String,String}
    request = nothing
    result = nothing
    index = 1
    while index <= length(arguments)
        flag = arguments[index]
        index == length(arguments) && error("missing value for $flag")
        if flag == "--request"
            request = arguments[index + 1]
        elseif flag == "--result"
            result = arguments[index + 1]
        else
            error("unknown argument: $flag")
        end
        index += 2
    end
    request === nothing && error("--request is required")
    result === nothing && error("--result is required")
    return String(request), String(result)
end

function require_exact_settings(request)
    String(request.protocol_version) == PROTOCOL_VERSION || error("unsupported protocol version")
    String(request.mode) == "raster_pairwise" || error("only raster pairwise mode is supported")
    String(request.raster_semantics) == "resistance" || error("conductance is unsupported")
    settings = request.settings
    String(settings.precision) == "double" || error("only double precision is supported")
    Int(settings.julia_threads) == 1 || error("julia_threads must be one")
    Int(settings.blas_threads) == 1 || error("blas_threads must be one")
    Int(settings.omp_threads) == 1 || error("omp_threads must be one")
    neighbor_rule = String(settings.neighbor_rule)
    neighbor_rule in ("FOUR", "EIGHT") || error("unsupported neighbor_rule: $neighbor_rule")
    resistance_average = String(settings.resistance_average)
    resistance_average in ("ARITHMETIC", "HARMONIC") ||
        error("unsupported resistance_average: $resistance_average")
end

function write_ini(request, root::String)::Tuple{String,String}
    resistance = checked_input_path(root, String(request.resources.resistance))
    focal = checked_input_path(root, String(request.resources.focal))
    included_pairs = checked_input_path(root, String(request.resources.included_pairs))
    output_directory = contained_output_path(root, String(request.output_directory))
    mkpath(output_directory)
    output_base = joinpath(output_directory, "connectivity")
    config_path = joinpath(root, "circuitscape.ini")
    four_neighbors = String(request.settings.neighbor_rule) == "FOUR"
    arithmetic = String(request.settings.resistance_average) == "ARITHMETIC"
    write_current = Bool(request.settings.emit_current_map)
    four_neighbors_value = four_neighbors ? "True" : "False"
    arithmetic_value = arithmetic ? "True" : "False"
    write_current_value = write_current ? "True" : "False"
    open(config_path, "w") do stream
        println(stream, "[Options for advanced mode]")
        println(stream, "ground_file_is_resistances = True")
        println(stream, "source_file = (Browse for a valid file)")
        println(stream, "ground_file = (Browse for a valid file)")
        println(stream, "use_unit_currents = False")
        println(stream, "use_direct_grounds = False")
        println(stream, "remove_src_or_gnd = keepall")
        println(stream, "[Mask file]")
        println(stream, "use_mask = False")
        println(stream, "mask_file = (Browse for a valid file)")
        println(stream, "[Calculation options]")
        println(stream, "low_memory_mode = False")
        println(stream, "parallelize = False")
        println(stream, "max_parallel = 1")
        println(stream, "solver = cg+amg")
        println(stream, "print_timings = False")
        println(stream, "preemptive_memory_release = True")
        println(stream, "print_rusages = False")
        println(stream, "scenario = pairwise")
        println(stream, "[Short circuit regions (aka polygons)]")
        println(stream, "use_polygons = False")
        println(stream, "polygon_file = (Browse for a valid file)")
        println(stream, "[Options for one-to-all and all-to-one modes]")
        println(stream, "use_variable_source_strengths = False")
        println(stream, "variable_source_file = (Browse for a valid file)")
        println(stream, "[Output options]")
        println(stream, "set_null_currents_to_nodata = False")
        println(stream, "set_null_voltages_to_nodata = False")
        println(stream, "compress_grids = True")
        println(stream, "write_cur_maps = $write_current_value")
        println(stream, "write_cum_cur_map_only = $write_current_value")
        println(stream, "log_transform_maps = False")
        println(stream, "write_volt_maps = False")
        println(stream, "output_file = $output_base")
        println(stream, "[Options for pairwise and one-to-all and all-to-one modes]")
        println(stream, "included_pairs_file = $included_pairs")
        println(stream, "use_included_pairs = True")
        println(stream, "point_file = $focal")
        println(stream, "[Connection scheme for raster habitat data]")
        println(stream, "connect_four_neighbors_only = $four_neighbors_value")
        println(stream, "connect_using_avg_resistances = $arithmetic_value")
        println(stream, "[Habitat raster or graph]")
        println(stream, "habitat_map_is_resistances = True")
        println(stream, "habitat_file = $resistance")
    end
    return config_path, output_base
end

function find_matrix(output_base::String)::String
    directory = dirname(output_base)
    candidates = filter(readdir(directory; join=true)) do path
        isfile(path) && endswith(lowercase(basename(path)), "_resistances_3columns.out")
    end
    isempty(candidates) && error("Circuitscape produced no effective-resistance matrix")
    return first(sort(candidates))
end

function parse_matrix(path::String, requested_pairs)
    values = Dict{Tuple{Int,Int},Float64}()
    for line in eachline(path)
        fields = split(strip(line))
        length(fields) < 3 && continue
        left_value = tryparse(Float64, fields[1])
        right_value = tryparse(Float64, fields[2])
        resistance = tryparse(Float64, fields[3])
        (left_value === nothing || right_value === nothing || resistance === nothing) && continue
        (isinteger(left_value) && isinteger(right_value)) || continue
        left = Int(left_value)
        right = Int(right_value)
        resistance > 0 || continue
        values[(min(left, right), max(left, right))] = resistance
    end
    metrics = Any[]
    for pair in requested_pairs
        left = Int(pair.from_focal_id)
        right = Int(pair.to_focal_id)
        key = (min(left, right), max(left, right))
        haskey(values, key) || error("matrix omits requested pair $(pair.pair_id)")
        push!(metrics, Dict(
            "pair_id" => String(pair.pair_id),
            "from_focal_id" => left,
            "to_focal_id" => right,
            "effective_resistance" => values[key],
        ))
    end
    return metrics
end

function relative_to_root(root::String, path::String)::String
    target = realpath(path)
    relative_target = relpath(target, realpath(root))
    (isabspath(relative_target) || ".." in splitpath(relative_target)) &&
        error("engine output escaped isolated run directory")
    return relative_target
end

function success_payload(request, root::String, matrix_path::String, pair_metrics)
    current_path = nothing
    if Bool(request.settings.emit_current_map)
        candidates = filter(readdir(dirname(matrix_path); join=true)) do path
            isfile(path) && occursin("cum_curmap", lowercase(basename(path)))
        end
        isempty(candidates) && error("requested cumulative current map was not produced")
        current_path = relative_to_root(root, first(sort(candidates)))
    end
    return Dict(
        "protocol_version" => PROTOCOL_VERSION,
        "status" => "SUCCEEDED",
        "engine_name" => "Circuitscape",
        "circuitscape_version" => ENGINE_VERSION,
        "pair_metrics" => pair_metrics,
        "matrix_path" => relative_to_root(root, matrix_path),
        "current_map_path" => current_path,
        "review_mask_summaries" => Any[],
        "warnings" => Any[],
        "failure_message" => nothing,
    )
end

function failure_payload(message::String)
    return Dict(
        "protocol_version" => PROTOCOL_VERSION,
        "status" => "FAILED",
        "engine_name" => "Circuitscape",
        "circuitscape_version" => ENGINE_VERSION,
        "pair_metrics" => Any[],
        "matrix_path" => nothing,
        "current_map_path" => nothing,
        "review_mask_summaries" => Any[],
        "warnings" => Any[],
        "failure_message" => message,
    )
end

function run(request_path::String, result_path::String)::Int
    root = pwd()
    request_absolute = checked_input_path(root, request_path)
    result_absolute = contained_output_path(root, result_path)
    try
        BLAS.set_num_threads(1)
        request = JSON3.read(read(request_absolute, String))
        require_exact_settings(request)
        config_path, output_base = write_ini(request, root)
        Circuitscape.compute(config_path)
        matrix_path = find_matrix(output_base)
        pair_metrics = parse_matrix(matrix_path, request.pairs)
        write(result_absolute, JSON3.write(success_payload(request, root, matrix_path, pair_metrics)))
        return 0
    catch error
        message = sprint(showerror, error)
        write(result_absolute, JSON3.write(failure_payload(message)))
        return 1
    end
end

Base.@ccallable function julia_main()::Cint
    try
        request_path, result_path = parse_args(ARGS)
        return Cint(run(request_path, result_path))
    catch error
        Base.display_error(Base.catch_stack())
        return Cint(2)
    end
end

end
